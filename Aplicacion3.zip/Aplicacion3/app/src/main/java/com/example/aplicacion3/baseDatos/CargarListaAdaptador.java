package com.example.aplicacion3.baseDatos;

import com.example.aplicacion3.listaOferta.objeto.tablaOfertas;

import java.util.ArrayList;

public class CargarListaAdaptador {

    public static ArrayList<tablaOfertas> cargarLista(){


        return null;
    }
}
