package com.example.aplicacion3.MetodosComunes;

public class ConstantesURL {


    // return "http://192.168.1.133/android/register.php"
    // return "https://heaven-sent-pull.000webhostapp.com/android/register.php";

    public static String registrarURL(){
         return "http://192.168.1.133/android/register.php";
        //return "https://heaven-sent-pull.000webhostapp.com/android/register.php";
    }

    public static String logearURL(){
         return "http://192.168.1.133/android/login.php";
       // return "https://heaven-sent-pull.000webhostapp.com/android/login.php";
    }

    public static String cargarListaURL(){
         return "http://192.168.1.133/android/lista.php";
      // return "https://heaven-sent-pull.000webhostapp.com/android/lista.php";
    }

}
